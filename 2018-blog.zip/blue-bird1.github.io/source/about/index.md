---
title: about
date: 2018-07-26 15:23:27
---

无业游民 死肥宅 网络安全爱好者 入门级编程

主要技能:
       1. python
       2. golang
       3. JavaScript
       4. web安全
       5. 安全开发
       6. 代码审计
       7. web开发
       8. 机器学习

次要技能
       1. linux
       2. 云计算
       3. 区块链
       4. 各种类型安全


 
