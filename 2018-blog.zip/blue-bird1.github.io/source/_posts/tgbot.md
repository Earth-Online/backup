---
title: telegraph机器人
date: 2018-08-19 02:37:05
tags:
---
写了个小telegraph机器人 调用yunsee.cn的查询功能
项目地址 https://mail.google.com/mail/u/1/#inbox
tg机器人 t.me/yunsee_bot
